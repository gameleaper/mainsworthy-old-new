mainsworthynew52.cpp   c++ source code, compile with DevC++ on windows OR use gcc on linux

mainsworthynew52.exe   windows executable compiled

mw    linux executable, place in your bin folder & start a terminal , then start it with "mw" in the terminal


there is an auto option to play a game against itself, you can do not use text command and generate a game movelist that you can copy & use in a database perhaps

it has a little randomness so play is unprodictable.

runs fine in arena for Linux . it runs on winboard for windows & arena for windows, ofcourse textmode works 



AFTER A COUPLE OF UPDATES ITS WORKING IN ARENA AND WINBOARD . ALSO A SPEED INCREASE. ARENA TOURNAMENTS ARE GREAT(I WOULD RECOMEND TO USE ARENA).

NOW HAS RANDOMIZED PLAY, SO ITS NOT BORING TO WATCH SAME GAME OVER & OVER AGAINST AN ENGINE(NOT ALL ENGINES DO THIS, AS IT SLIGHTLY WEAKENS IT) ALSO TEXT DISPLAY HAS WHITE AND BLACK SQUARES FOR BETTER NAVIGATION ON THE BOARD

its a text chess engine that can also be plugged into winboard with basic commants go move & quit , or installed into arena for watching and playing engines.  

Its compiled for LINUX & a Windows version. source code included,so you can compile yourself looks complex in Linux but its super easy with gcc on Linux(login as root ,start a terminal, then gcc filename.cpp then rename a.out to mw set execute permission runit by typing mw), or compile with DevC++ for windows ,standard c++ compilers will very likely work too, only one c++ source file, so compile easily.

the souce code has static arrays for move generation, and an unusual evaluator.

I have added an auto function to generate games and output the movelist for use in other apps like databases perhaps. I believe Linux can pipe it too

winboard software can be got here
http://www.open-aurec.com/wbforum/viewtopic.php?f=19&t=51528  

Arena that is simply brilliant too here
http://www.playwitharena.com/
